__version__ = '5.0.0'


def get_version():
    return __version__
